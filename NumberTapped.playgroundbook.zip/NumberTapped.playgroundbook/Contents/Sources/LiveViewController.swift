//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import AVFoundation
import PlaygroundSupport

@objc(Book_Sources_LiveViewController)
public class LiveViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {

	//UIパーツの定義
	public let resetButton:UIButton = UIButton()
	var numberView:UIView = UIView()
	
	private var baseYellow:UIColor = UIColor(red:0.97, green:0.90, blue:0.59, alpha:1.00)
	private var baseBlue:UIColor = UIColor(red:0.43, green:0.57, blue:0.80, alpha:1.00)
	
	var deviceWidth:Int = 0
	var deviceHeight:Int = 0
	
	public var lineNumber:Int = 2
	public var columnNumber:Int = 2
	
	public var numberButton:UIButton!
	
	//backgroundパラメータ
	public var backgroundColor:UIColor = UIColor.white
	
	//数字オブジェクトのパラメータ
	public var fontSize:CGFloat = 100
	public var fontColor:UIColor = .black
	public var isRotate:Bool = true

	var numberViewWidth:CGFloat = 100
	var numberviewHeight:CGFloat = 100
	
	var gridCordinate:[CGPoint] = []
	
	public var numberButtonColor:UIColor = .black
	public var numberButtonTappedColor:UIColor = .red
	
	public func receive(_ message: PlaygroundValue) {
		// Implement this method to receive messages sent from the process running Contents.swift.
		// This method is *required* by the PlaygroundLiveViewMessageHandler protocol.
		// Use this method to decode any messages sent as PlaygroundValue values and respond accordingly.
	}
	
	public override func viewWillAppear(_ animated: Bool) {
		super.viewWillAppear(animated)
		
		deviceWidth = Int(self.view.frame.width)
		deviceHeight = Int(self.view.frame.height)
		
		resetObject()
		
	}
	
	public override func viewDidAppear(_ animated: Bool) {
		let width = self.view.frame.width
		let height = self.view.frame.height
		
		//number view
		numberView.frame = CGRect(x: 0, y: 0, width: width, height: height)
		numberView.backgroundColor = baseYellow
		self.view.addSubview(numberView)
		
		numberViewWidth = numberView.frame.width
		numberviewHeight = numberView.frame.height
		
		
		//reset button
		/*
		resetButton.frame = CGRect(x: 0, y: 0, width: 80, height: 80)
		resetButton.setTitleColor(.white, for: .normal)
		resetButton.titleLabel?.textAlignment = .right
		resetButton.backgroundColor = baseBlue
		resetButton.setTitle("リセット", for: .normal)
		resetButton.addTarget(self, action: #selector(resetObject), for: .touchUpInside)
		
		resetButton.layer.cornerRadius = 40
		*/
		resetButton.center = CGPoint(x: width/10*9, y: height/10*9)
		resetButton.addTarget(self, action: #selector(resetObject), for: .touchUpInside)
		self.view.addSubview(resetButton)
		resetObject()
	}
	
	public override func viewDidLoad() {
		super.viewDidLoad()
	}
	

	@objc func resetObject() {
		//subviewの削除
		removeAllSubviews(parentView: numberView)
		
		initGridCordinate()
		
		for i in 0 ..< columnNumber*lineNumber{
			let objectNumber:Int = Int.random(in: 1 ... 5)
			self.numberView.addSubview(createNumberObject(cordinate: gridCordinate[i], number: objectNumber))
		}
	}
	
	//ボタンの配置を初期化する処理
	func initGridCordinate() {
		
		self.gridCordinate.removeAll()
		
		var counter = 0
		
		for i in 0 ..< lineNumber {
			
			let gridY = numberviewHeight/(CGFloat(lineNumber)+1) * (CGFloat(i) + 1)
			
			for j in 0 ..< columnNumber {
				let gridX = numberViewWidth / (CGFloat(columnNumber)+1) * (CGFloat(j) + 1)
				
				let cordinate:CGPoint = CGPoint(x: gridX, y: gridY)
				gridCordinate.append(cordinate)
				
				counter += 1
				
			}
			
		}
	}
	
	//1つ1つの数字オブジェクトを作る処理
	public func createNumberObject(cordinate:CGPoint, number:Int)->UIButton {
		
		let randomNumberX:CGFloat = CGFloat(Int.random(in: -50 ... 50))
		let randomNumberY:CGFloat = CGFloat(Int.random(in: -20 ... 20))
		
		let rotationAngleInt:Int = Int.random(in: 0 ... 360)
		let rotationAngle:CGFloat = CGFloat(integerLiteral: rotationAngleInt)
		
		//let numberButton:UIButton = UIButton()
		//numberButton.backgroundColor = baseBlue
		
		
		
		numberButton = UIButton()
		numberButton.setTitle(String(number), for: .normal)
		numberButton.setTitleColor(numberButtonColor, for: .normal)
		numberButton.titleLabel?.font = UIFont(name: "Helvetica-Bold", size: fontSize)
		numberButton.sizeToFit()
		numberButton.layer.position = CGPoint(x: cordinate.x + randomNumberX, y: cordinate.y + randomNumberY)
		
		if isRotate {
			numberButton.transform = CGAffineTransform(rotationAngle: rotationAngle)
		}
		
		numberButton.addTarget(self, action: #selector(self.buttonTapped(sender:)), for: .touchUpInside)
		
		
		
		return numberButton
		
	}
	
	
	
	//数字オブジェクトがタップされたときの処理
	@objc func buttonTapped(sender: UIButton) {
		sender.setTitleColor(.gray, for: .normal)
	}
	
	//数字オブジェクトを削除する処理
	func removeAllSubviews(parentView: UIView){
		var subviews = parentView.subviews
		for subview in subviews {
			subview.removeFromSuperview()
		}
	}
	
}
