//#-hidden-code

import UIKit
import PlaygroundSupport

let page = PlaygroundPage.current
page.needsIndefiniteExecution = true
let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy

func explore() {
	proxy?.send(.string("explore"))
}

let view = LiveViewController()
page.liveView = view

//#-end-hidden-code

/*:
## ボタンの数を決める
まずは表示するボタンの数を決めましょう。
縦（columnNumber）と横（lineNumber）に表示する数をそれぞれの変数に指定します。
*/

/*:
横に並べる数
:*/
view.lineNumber = /*#-editable-code placeholder text*/0/*#-end-editable-code*/
/*:
縦に並べる数
*/
view.columnNumber = /*#-editable-code placeholder text*/0/*#-end-editable-code*/

/*:
## ボタンの見た目を調整する
数字の見た目も調整しましょう
*/

/*:
フォントの大きさ
*/
view.fontSize = /*#-editable-code placeholder text*/10/*#-end-editable-code*/

/*:
ランダムに回転させるかどうか
*/
view.isRotate = /*#-editable-code placeholder text*/true/*#-end-editable-code*/
view.numberButtonColor = UIColor/*#-editable-code placeholder text*/.black/*#-end-editable-code*/

