//#-hidden-code

import UIKit
import PlaygroundSupport

let page = PlaygroundPage.current
page.needsIndefiniteExecution = true
let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy

func explore() {
	proxy?.send(.string("explore"))
}

let view = LiveViewController()
page.liveView = view

//#-end-hidden-code

/*:
## 数字のボタンを作ろう
タップするための数字ボタンを作ります。
まずは表示するボタンの数を決めましょう。
縦（columnNumber）と横（lineNumber）に表示する数をそれぞれの変数に指定します。
*/

/*:
横に並べる数
:*/
view.lineNumber = /*#-editable-code placeholder text*/2/*#-end-editable-code*/
/*:
縦に並べる数
*/
view.columnNumber = /*#-editable-code placeholder text*/2/*#-end-editable-code*/

/*:
### ボタンの見た目を調整する
数字の見た目も調整しましょう
*/

/*:
フォントの大きさ
*/
view.fontSize = /*#-editable-code placeholder text*/10/*#-end-editable-code*/

/*:
ランダムに回転させるかどうか
*/
view.isRotate = /*#-editable-code placeholder text*/true/*#-end-editable-code*/


/*:
ボタンが押されたときに数字の色を変えます。灰色に設定してみましょう。
*/
view.numberButtonColor = UIColor/*#-editable-code placeholder text*/.black/*#-end-editable-code*/
view.numberButtonTappedColor = UIColor/*#-editable-code placeholder text*/.gray/*#-end-editable-code*/

/*:
# リセットボタンを作る
*/

view.resetButton.frame = CGRect(x: 0, y:0, width: 80, height: 80)
view.resetButton.setTitleColor(/*#-editable-code placeholder text*/.white/*#-end-editable-code*/, for: .normal)
view.resetButton.backgroundColor = UIColor/*#-editable-code placeholder text*/.blue/*#-end-editable-code*/
view.resetButton.setTitle(/*#-editable-code placeholder text*/"テキストを入力"/*#-end-editable-code*/, for: .normal)
view.resetButton.layer.cornerRadius = /*#-editable-code placeholder text*/0/*#-end-editable-code*/
